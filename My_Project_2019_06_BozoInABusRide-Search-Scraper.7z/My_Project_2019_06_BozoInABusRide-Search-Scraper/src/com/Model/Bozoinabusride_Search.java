package com.Model;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bozoinabusride_Search {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "D:\\Tushar\\JARs\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://bozoinabusride.blogspot.com/");
		driver.manage().window().maximize();
		WebElement searchThis = driver.findElement(By.name("q"));

		searchThis.sendKeys("silver");//Enter keyword to be Searched here...
		
		driver.findElement(By.className("gsc-search-button")).click();

	}

}
